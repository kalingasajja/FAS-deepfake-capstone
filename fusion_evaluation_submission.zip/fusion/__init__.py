"""
Multimodal Late Fusion Engine
"""
